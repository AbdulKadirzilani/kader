from django.apps import AppConfig


class QostsConfig(AppConfig):
    name = 'Qosts'
