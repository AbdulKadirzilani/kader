from django.db import models
from django.urls import reverse

class Qost(models.Model):

    title = models.CharField(max_length=100)
    content = models.TextField()
    image = models.FileField(null=True,blank=True)
    createdat = models.DateTimeField(auto_now=False, auto_now_add=True)
    update = models.DateTimeField(auto_now = True , auto_now_add = False)

    #image2 = models.ImageField(upload_to="pro_img", blank=True)
    '''
    img= models.ImageField(null=True,
                           blank=True,
                           width_field='width_field',
                           height_field='height_field',)

    width_field = models.IntegerField(default=0)
    height_field = models.IntegerField(default=0)
    '''
    #def get_absolute_url(self):
        #return reverse("detailsN",kwargs={"id":self})