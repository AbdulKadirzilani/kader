from django.shortcuts import HttpResponse,redirect
from django.shortcuts import render,get_object_or_404
from django.contrib import messages
from .models import Qost
from .forms import QostForm

def details(request,pid):
    a= get_object_or_404(Qost,id=pid)

    context = {

         "a":a
    }
    return render(request, 'details.html', context)


def post_home(request):
    queryset = Qost.objects.all().order_by("-createdat")
    context = {
        "title" : "Home",
        "content": "Home",
        "result_list":queryset
    }

    return render(request, 'post_home.html', context)


def CreatePost(request):
        form = QostForm(request.POST or None,request.FILES or None)
        if form.is_valid():
            instance = form.save(commit = False)# a line na dileo hobe
            instance.save()
            messages.success(request, "Successfully Created")
            return redirect('post_home')
        context = {'form' : form}

        return render(request, 'post_form.html',context)
'''

def CreatePost(request):
    if request.method == "POST":
        form =QostForm(request.POST)
        if form.is_valid():
            instance = form.save(commit=False)
            instance.save()
        messages.sucess(request, 'Registration sucessfully')
            return ()

    else:
        form = QostForm()
    return render(request, 'signup.html',{'form':form})
'''


def UpdatePost(request, id = None):
        instance= get_object_or_404(Qost, id=id)
        form = QostForm(request.POST or None,instance=instance)
        if form.is_valid():
           instance = form.save(commit = False)# a line na dileo hobe
           instance.save()

        context = {'form' : form,"instance":instance}

        return render(request, 'post_form.html',context)





def DeletePost(request,pid):
    a = Qost.objects.get(id=pid)
    a.delete()
    messages.success(request, 'delete sucessfully')
    return redirect('post_home')
    #messages.success(request, 'delete sucessfully')

def showall(request):
    ak = Qost.objects.all()
    c = { 'a':ak}
    #messages.success(request, 'delete sucessfully')
    return render(request,'zila/show.html',c)

'''
def my_expense(request):
    expenses = Expense.objects.all()
    context = {'expenses': expenses}
    return render(request,'cost/expense.html', context)
'''






'''

def CreatePost(request):

    if request.method == 'POST':
        form = QostForm(request.POST)
        form.save()
        return HttpResponse("CreateSuccessful")
    else:
        form = QostForm

    return render(request, 'post_form.html', {'form':form})
'''
